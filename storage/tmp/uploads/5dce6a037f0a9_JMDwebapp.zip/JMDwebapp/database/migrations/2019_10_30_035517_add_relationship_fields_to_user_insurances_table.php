<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToUserInsurancesTable extends Migration
{
    public function up()
    {
        Schema::table('user_insurances', function (Blueprint $table) {
            $table->unsignedInteger('user_id');

            $table->foreign('user_id', 'user_fk_538286')->references('id')->on('users');

            $table->unsignedInteger('assistance_id');

            $table->foreign('assistance_id', 'assistance_fk_538287')->references('id')->on('assistances');

            $table->unsignedInteger('insurance_id');

            $table->foreign('insurance_id', 'insurance_fk_538288')->references('id')->on('insurances');
        });
    }
}
