<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToInsurancesTable extends Migration
{
    public function up()
    {
        Schema::table('insurances', function (Blueprint $table) {
            $table->unsignedInteger('assistance_id');

            $table->foreign('assistance_id', 'assistance_fk_538125')->references('id')->on('assistances');
        });
    }
}