<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserInsurancesTable extends Migration
{
    public function up()
    {
        Schema::create('user_insurances', function (Blueprint $table) {
            $table->increments('id');

            $table->float('amount', 15, 2);

            $table->timestamps();

            $table->softDeletes();
        });
    }
}
