<?php

use App\User;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        $users = [
            [
                'id'             => 1,
                'family_name'   => 'fadmin',
                'name'=>'admin',
                'email'          => 'admin@admin.com',
                'password'       => '$2y$10$FjcfuoUC/XDrbI.zaaV9ZuDDgOF5tu0VaZeFODubHqdQ793N8PL2y',
                'ref_no'=>'JMDM190322-2-E-18',
                'gender'=>'male',
                'passport'=>'asdfsa345254',
                'address'=>'No.21,5th Floor , Hin Tha Da Street Sanchaung Township,Yangon,Myanmar',
                'Phone'=>'+09123412341234',
                'remember_token' => null,
                'approved'           => 1,
                'verified'           => 1,
                'verified_at'        => '2019-10-29 08:33:45',
                'verification_token' => '',
            ],
            [
                'id'             => 2,
                'family_name'   => 'fuser',
                'name'=>'user',
                'email'          => 'user@user.com',
                'password'       => '$2y$10$FjcfuoUC/XDrbI.zaaV9ZuDDgOF5tu0VaZeFODubHqdQ793N8PL2y',
                'ref_no'=>'JMDM190322-2-E-18',
                'gender'=>'female',
                'passport'=>'asdfsa345254',
                'address'=>'No.21,5th Floor , Hin Tha Da Street Sanchaung Township,Yangon,Myanmar',
                'Phone'=>'+09123412341234',
                'remember_token' => null,
                'approved'           => 1,
                'verified'           => 1,
                'verified_at'        => '2019-10-29 08:33:45',
                'verification_token' => '',
            ],
            [
                'id'             => 3,
                'family_name'   => 'fmember',
                'name'=>'member',
                'email'          => 'member@member.com',
                'password'       => '$2y$10$FjcfuoUC/XDrbI.zaaV9ZuDDgOF5tu0VaZeFODubHqdQ793N8PL2y',
                'gender'=>'male',
                'ref_no'=>'JMDM190322-2-E-18',
                'passport'=>'asdfsa345254',
                'address'=>'No.21,5th Floor , Hin Tha Da Street Sanchaung Township,Yangon,Myanmar',
                'Phone'=>'+09123412341234',
                'remember_token' => null,
                'approved'           => 1,
                'verified'           => 1,
                'verified_at'        => '2019-10-29 08:33:45',
                'verification_token' => '',
            ],
        ];

        User::insert($users);
    }
}
