<?php

use App\Permission;
use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            [
                
                'title' => 'user_management_access',
            ],
            [
               
                'title' => 'permission_create',
            ],
            [
                
                'title' => 'permission_edit',
            ],
            [
               
                'title' => 'permission_show',
            ],
            [
                
                'title' => 'permission_delete',
            ],
            [
                
                'title' => 'permission_access',
            ],
            [
                
                'title' => 'role_create',
            ],
            [
                
                'title' => 'role_edit',
            ],
            [
               
                'title' => 'role_show',
            ],
            [
               
                'title' => 'role_delete',
            ],
            [
                
                'title' => 'role_access',
            ],
            [
               
                'title' => 'user_create',
            ],
            [
                
                'title' => 'user_edit',
            ],
            [
               
                'title' => 'user_show',
            ],
            [
              
                'title' => 'user_delete',
            ],
            [
                
                'title' => 'user_access',
            ],
            
            [
               
                'title' => 'news_create',
            ],
            [
                
                'title' => 'news_edit',
            ],
            [
                
                'title' => 'news_show',
            ],
            [
                
                'title' => 'news_delete',
            ],
            [
                
                'title' => 'news_access',
            ],
            [
                
                'title' => 'setting',
            ],
            [
                
                'title' => 'members',
            ],
            [
               
                'title' => 'members_create',
            ],
            [
                
                'title' => 'members_edit',
            ],
            [
                
                'title' => 'members_show',
            ],
            [
                
                'title' => 'members_delete',
            ],
            [
            
                'title' => 'user_alert_create',
            ],
            [
              
                'title' => 'user_alert_show',
            ],
            [
               
                'title' => 'user_alert_delete',
            ],
            [
              
                'title' => 'user_alert_access',
            ],
            [
                'title' => 'hospitals_create',
            ],
            [
                'title' => 'hospitals_edit',
            ],
            [
                'title' => 'hospitals_show',
            ],
            [
                'title' => 'hospitals_delete',
            ],
            [
                'title' => 'hospitals_access',
            ],
            [
                'title' => 'doctors_create',
            ],
            [
                'title' => 'doctors_edit',
            ],
            [
                'title' => 'doctors_show',
            ],
            [
                'title' => 'doctors_delete',
            ],
            [
                'title' => 'doctors_access',
            ],
            [
                'title' => 'medicals_create',
            ],
            [
                'title' => 'medicals_edit',
            ],
            [
                'title' => 'medicals_show',
            ],
            [
                'title' => 'medicals_delete',
            ],
            [
                'title' => 'medicals_access',
            ],
            [
                'title' => 'assistance_create',
            ],
            [
                'title' => 'assistance_edit',
            ],
            [
                'title' => 'assistance_show',
            ],
            [
                'title' => 'assistance_delete',
            ],
            [
                'title' => 'assistance_access',
            ],
              [
                'title' => 'insurance_create',
            ],
            [
                'title' => 'insurance_edit',
            ],
            [
                'title' => 'insurance_show',
            ],
            [
                'title' => 'insurance_delete',
            ],
            [
                'title' => 'insurance_access',
            ],
              [
                'title' => 'user_insurance_create',
            ],
            [
                'title' => 'user_insurance_edit',
            ],
            [
                'title' => 'user_insurance_show',
            ],
            [
                'title' => 'user_insurance_delete',
            ],
            [
                'title' => 'user_insurance_access',
            ],
              [
                'title' => 'invoice_create',
            ],
            [
                'title' => 'invoice_edit',
            ],
            [
                'title' => 'invoice_show',
            ],
            [
                'title' => 'invoice_delete',
            ],
            [
                'title' => 'invoice_access',
            ],
        ];

        Permission::insert($permissions);
    }
}
