<?php

use Illuminate\Database\Seeder;

class MediaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('media')->insert(
            [
                
                'model_type' => 'App\News',
                'model_id' => 5,
                'name' => '5db2aa16c4edc_Myanmar3_Unicode_keyboard_Layout',
                'collection_name'=>"news_images",
                'file_name' => '5db2aa16c4edc_Myanmar3_Unicode_keyboard_Layout.jpg',
                'mime_type' => 'image/jpeg',
                'disk' => 'public',
                'size' => 125270,
                'manipulations' => '[]',
                'custom_properties' => '{"generated_conversions":{"thumb":true}}',
                'responsive_images' => '[]',
                'order_column' => 1
                

            ]);
         DB::table('media')->insert(
             [
                
                'model_type' => 'App\News',
                'model_id' => 4,
                'name' => '5db2ab68f35b1_Bagan',
                'collection_name'=>"news_images",
                'file_name' => '5db2ab68f35b1_Bagan.jpg',
                'mime_type' => 'image/jpeg',
                'disk' => 'public',
                'size' => 206533,
                'manipulations' => '[]',
                'custom_properties' => '{"generated_conversions":{"thumb":true}}',
                'responsive_images' => '[]',
                'order_column' => 2
                

             ]);
              DB::table('media')->insert(
             [
                
                'model_type' => 'App\News',
                'model_id' => 3,
                'name' => '5db2ab92d0ac7_KYAINGTONG',
                'collection_name'=>"news_images",
                'file_name' => '5db2ab92d0ac7_KYAINGTONG.jpg',
                'mime_type' => 'image/jpeg',
                'disk' => 'public',
                'size' => 282880,
                'manipulations' => '[]',
                'custom_properties' => '{"generated_conversions":{"thumb":true}}',
                'responsive_images' => '[]',
                'order_column' => 3
                

             ]);
              DB::table('media')->insert(
             [
                
                'model_type' => 'App\News',
                'model_id' => 2,
                'name' => '5db2ab9eb2247_Mandalay',
                'collection_name'=>"news_images",
                'file_name' => '5db2ab9eb2247_Mandalay.jpg',
                'mime_type' => 'image/jpeg',
                'disk' => 'public',
                'size' => 168484,
                'manipulations' => '[]',
                'custom_properties' => '{"generated_conversions":{"thumb":true}}',
                'responsive_images' => '[]',
                'order_column' => 4
                

             ]);
              DB::table('media')->insert(
             [
                
                'model_type' => 'App\News',
                'model_id' => 1,
                'name' => '5db2abaa3938b_Sittwe,_Burma',
                'collection_name'=>"news_images",
                'file_name' => '5db2abaa3938b_Sittwe,_Burma.jpg',
                'mime_type' => 'image/jpeg',
                'disk' => 'public',
                'size' => 200614,
                'manipulations' => '[]',
                'custom_properties' => '{"generated_conversions":{"thumb":true}}',
                'responsive_images' => '[]',
                'order_column' => 5
                

             ]

            );
    
 }
}
