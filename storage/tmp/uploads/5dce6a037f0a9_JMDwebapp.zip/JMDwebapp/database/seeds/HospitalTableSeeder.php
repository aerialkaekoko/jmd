<?php
use App\Hospital;

use Illuminate\Database\Seeder;

class HospitalTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $hospitals= [
            [
                
                'name' => 'Hospital One',
                'country' => 'Myanmar',
                'address' => 'Sanchaung, Myanmar',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            ],
            [                
                'name' => 'Hospital Two',
                'country' => 'Thailand',
                'address' => '61/4 Sukhumvit Soi 1, Klongtoey-nua, Wattana, Bangkok, Thailand',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                
                
            ],
            [                
                'name' => 'Hospital Three',
                'country' => 'Vietnam',
                'address' => 'Địa chỉ: 40 Phố Tràng Thi - Hà Nội - Việt Nam',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',                
                
            ],          

        ];

    Hospital::insert($hospitals);

    }
}
