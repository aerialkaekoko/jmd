<?php

Route::redirect('/', '/admin');


Route::get('/home', function () {
    if (session('status')) {
        return redirect()->route('admin.home')->with('status', session('status'));
    }

    return redirect()->route('admin.home');
});

Auth::routes(['register' => false]);
Route::get('userVerification/{token}', 'UserVerificationController@approve')->name('userVerification');
Route::get('user-alerts/read', 'UserAlertsController@read');



Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth']], function () {
     Route::get('/', 'HomeController@index')->name('home');
    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');
    
    Route::post('users/media', 'UsersController@storeMedia')->name('users.storeMedia');
    

    // Members
    Route::resource('members', 'MembersController');
    Route::delete('members/destroy', 'MembersController@massDestroy')->name('members.massDestroy');
    Route::post('members/media', 'MembersController@storeMedia')->name('members.storeMedia');

    // User Alerts
    Route::delete('user-alerts/destroy', 'UserAlertsController@massDestroy')->name('user-alerts.massDestroy');
    Route::resource('user-alerts', 'UserAlertsController', ['except' => ['edit', 'update']]);

    Route::get('messenger', 'MessengerController@index')->name('messenger.index');
    Route::get('messenger/create', 'MessengerController@createTopic')->name('messenger.createTopic');
    Route::post('messenger', 'MessengerController@storeTopic')->name('messenger.storeTopic');
    Route::get('messenger/inbox', 'MessengerController@showInbox')->name('messenger.showInbox');
    Route::get('messenger/outbox', 'MessengerController@showOutbox')->name('messenger.showOutbox');
    Route::get('messenger/{topic}', 'MessengerController@showMessages')->name('messenger.showMessages');
    Route::delete('messenger/{topic}', 'MessengerController@destroyTopic')->name('messenger.destroyTopic');
    Route::post('messenger/{topic}/reply', 'MessengerController@replyToTopic')->name('messenger.reply');
    Route::get('messenger/{topic}/reply', 'MessengerController@showReply')->name('messenger.showReply');

    // news
    Route::delete('news/destroy', 'NewsController@massDestroy')->name('news.massDestroy');
    Route::post('news/media', 'NewsController@storeMedia')->name('news.storeMedia');
    Route::post('news/parse-csv-import', 'NewsController@parseCsvImport')->name('news.parseCsvImport');
    Route::post('news/process-csv-import', 'NewsController@processCsvImport')->name('news.processCsvImport');
    Route::resource('news', 'NewsController');

    // Hospitals
    Route::delete('hospitals/destroy', 'HospitalController@massDestroy')->name('hospitals.massDestroy');
    Route::post('hospitals/media', 'HospitalController@storeMedia')->name('hospitals.storeMedia');
    Route::resource('hospitals', 'HospitalController');

 // Assistances
 Route::delete('assistances/destroy', 'AssistanceController@massDestroy')->name('assistances.massDestroy');
 Route::resource('assistances', 'AssistanceController');

 // Insurances
 Route::delete('insurances/destroy', 'InsuranceController@massDestroy')->name('insurances.massDestroy');
 Route::resource('insurances', 'InsuranceController');

 // User Insurances
 Route::delete('user-insurances/destroy', 'UserInsuranceController@massDestroy')->name('user-insurances.massDestroy');
 Route::resource('user-insurances', 'UserInsuranceController');
 Route::get('/get_insurances/{id}', 'UserInsuranceController@get_insurance');

 // Invoices
 // Route::delete('insurances/destroy', 'InsuranceController@massDestroy')->name('insurances.massDestroy');
 Route::resource('invoices', 'InvoicesController');
 Route::get('/get_user_insurance/{id}', 'InvoicesController@get_user_insurance');
 Route::get('/delete_expense/{id}', 'InvoicesController@delete_expense');
    // Doctors
    Route::delete('doctors/destroy', 'DoctorController@massDestroy')->name('doctors.massDestroy');
    Route::post('doctors/media', 'DoctorController@storeMedia')->name('doctors.storeMedia');
    Route::resource('doctors', 'DoctorController');

    // Medicals
    Route::delete('medicals/destroy', 'MedicalController@massDestroy')->name('medicals.massDestroy');
    Route::post('medicals/media', 'MedicalController@storeMedia')->name('medicals.storeMedia');
    Route::resource('medicals', 'MedicalController');

});
