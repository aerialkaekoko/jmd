<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\StoreInvoiceRequest;
use App\Http\Requests\UpdateInvoiceRequest;
use Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Invoice;
use App\MedicalExpense;
use App\User;
use App\Hospital;

class InvoicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        abort_if(Gate::denies('invoice_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $invoices = Invoice::all();

        return view('admin.invoices.index', compact('invoices'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        abort_if(Gate::denies('invoice_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $users = User::whereHas('roles' , function($q){
            $q->where('title', 'Member');
        })->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $hospitals = Hospital::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        return view('admin.invoices.create',compact('users','hospitals'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreInvoiceRequest $request)
    {
        // dd($request->all());
        $invoice = new Invoice;
        $invoice->invoice_code = $request->invoice_code;
        $invoice->reference_no = $request->reference_no;
        $invoice->user_id = $request->user_id;
        $invoice->hospital_id = $request->hospital_id;
        $invoice->receive_type = $request->payment_type;
        $invoice->insurance_id = $request->insurance_id;
        if ($invoice->save()) {
           foreach ($request->expense_group as $key => $value) {
               if (isset($value['expense_type'])) {
                    $medical_expense = new MedicalExpense;
                    $medical_expense->invoice_id = $invoice->id;
                    $medical_expense->expense_type = $value['expense_type'];
                    $medical_expense->expense_amount = $value['expense_amount'];
                    $medical_expense->save();
               }
           }
        }
        return redirect()->route('admin.invoices.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Invoice $invoice)
    {
        abort_if(Gate::denies('invoice_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.invoices.show',compact('invoice'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Invoice $invoice)
    {
        abort_if(Gate::denies('invoice_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        // dd($invoice);
        $users = User::all()->pluck('name','id')->prepend(trans('global.pleaseSelect'), '');
        $medical_expenses = $invoice->medical_expenses;
        $hospitals = Hospital::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        return view('admin.invoices.edit',compact('users','invoice','medical_expenses','hospitals'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateInvoiceRequest $request, Invoice $invoice)
    {
        // dd($request->all());
        $invoice->invoice_code = $request->invoice_code;
        $invoice->reference_no = $request->reference_no;
        $invoice->user_id = $request->user_id;
        $invoice->hospital_id = $request->hospital_id;
        $invoice->receive_type = $request->payment_type;
        $invoice->insurance_id = $request->insurance_id;
        if ($invoice->save()) {
           foreach ($request->expense_group as $key => $value) {
               if (isset($value['expense_type'])) {
                    $medical_expense =MedicalExpense::find($value['expense_id']);
                    if ($medical_expense != null) {
                        $medical_expense->invoice_id = $invoice->id;
                        $medical_expense->expense_type = $value['expense_type'];
                        $medical_expense->expense_amount = $value['expense_amount'];
                        $medical_expense->save();
                    } else {
                        $medical_expense = new MedicalExpense;
                        $medical_expense->invoice_id = $invoice->id;
                        $medical_expense->expense_type = $value['expense_type'];
                        $medical_expense->expense_amount = $value['expense_amount'];
                        $medical_expense->save();
                    }
                    
               }
           }
        }
        return redirect()->route('admin.invoices.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Invoice $invoice)
    {
        abort_if(Gate::denies('invoice_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $invoice->medical_expenses()->delete();
        $invoice->delete();
        return back();
    }
    public function get_user_insurance($user_id)
    {
        $user_insurances = User::find($user_id)->insurances()->get();
        return response()->json(['success'=>true,'data'=>$user_insurances]);
    }
    public function delete_expense($id)
    {
        $medical_expense = MedicalExpense::find($id);
        if ($medical_expense->delete()) {
            return response()->json(['success'=>true]);
        }
    }
}
