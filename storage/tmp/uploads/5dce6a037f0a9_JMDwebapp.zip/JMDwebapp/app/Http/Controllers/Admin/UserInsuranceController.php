<?php

namespace App\Http\Controllers\Admin;

use App\Assistance;
use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyUserInsuranceRequest;
use App\Http\Requests\StoreUserInsuranceRequest;
use App\Http\Requests\UpdateUserInsuranceRequest;
use App\Insurance;
use App\User;
use App\UserInsurance;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class UserInsuranceController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('user_insurance_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $userInsurances = UserInsurance::all();

        return view('admin.user-insurances.index', compact('userInsurances'));
    }

    public function create()
    {
        abort_if(Gate::denies('user_insurance_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $users = User::whereHas('roles' , function($q){
            $q->where('title', 'Member');
        })->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $assistances = Assistance::all()->pluck('assistance_name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $insurances = Insurance::all()->pluck('company_name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.user-insurances.create', compact('users', 'assistances', 'insurances'));
    }

    public function store(StoreUserInsuranceRequest $request)
    {
        $userInsurance = UserInsurance::create($request->all());

        return redirect()->route('admin.user-insurances.index');
    }

    public function edit(UserInsurance $userInsurance)
    {
        abort_if(Gate::denies('user_insurance_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::whereHas('roles' , function($q){
            $q->where('title', 'Member');
        })->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $assistances = Assistance::all()->pluck('assistance_name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $insurances = Assistance::find($userInsurance->assistance_id)->insurances->pluck('company_name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $userInsurance->load('user', 'assistance', 'insurance');

        return view('admin.user-insurances.edit', compact('users', 'assistances', 'insurances', 'userInsurance'));
    }

    public function update(UpdateUserInsuranceRequest $request, UserInsurance $userInsurance)
    {
        $userInsurance->update($request->all());

        return redirect()->route('admin.user-insurances.index');
    }

    public function show(UserInsurance $userInsurance)
    {
        abort_if(Gate::denies('user_insurance_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $userInsurance->load('user', 'assistance', 'insurance');

        return view('admin.user-insurances.show', compact('userInsurance'));
    }

    public function destroy(UserInsurance $userInsurance)
    {
        abort_if(Gate::denies('user_insurance_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $userInsurance->delete();

        return back();
    }

    public function massDestroy(MassDestroyUserInsuranceRequest $request)
    {
        UserInsurance::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
    public function get_insurance($assistance_id)
    {
        $assistance = Assistance::find($assistance_id);
        $insurances = $assistance->insurances;
        return response()->json(['success'=>true,'data'=>$insurances]);
    }
}
