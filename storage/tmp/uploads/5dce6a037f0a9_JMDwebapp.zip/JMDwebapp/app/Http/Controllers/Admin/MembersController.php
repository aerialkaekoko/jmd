<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StoreMembersRequest;
use App\Http\Requests\UpdateMembersRequest;
use App\Role;
use App\User;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class MembersController extends Controller
{
    use MediaUploadingTrait;

    //  index
    public function index()
    {
        abort_if(Gate::denies('members'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::whereHas('roles', function ($q) {$q->whereIn('roles.title', ['member']);})->get();

         return view('admin.members.index', compact('users'));


    }

    //create
    public function create(User $user)
    {
        
     return view('admin.members.create');
    }

    //edit
   public function edit(Request $request,$id)
    {
        abort_if(Gate::denies('members_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

          $roles = Role::all()->pluck('title', 'id');
          $user = User::find($id);
          
        return view('admin.members.edit', compact('roles', 'user'));
    }

    //store
    public function store(Request $request)
    {
        $user = User::create($request->all());
        $user->roles()->sync($request->input('roles', [3]));

        foreach ($request->input('passport_info', []) as $file) {
            $user->addMedia(storage_path('tmp/uploads/' . $file))->toMediaCollection('passport_info');
        }

        foreach ($request->input('insurance', []) as $file) {
            $user->addMedia(storage_path('tmp/uploads/' . $file))->toMediaCollection('insurance');
        }

        return redirect()->route('admin.members.index');
    }

    //update
    public function update(UpdateMembersRequest $request, $id)

    {
        $user = User::find($id);
        $user->update($request->all());
        // $user->roles()->sync($request->input('roles', [3]));

        if (count($user->passport_info) > 0) {
            foreach ($user->passport_info as $media) {
                if (!in_array($media->file_name, $request->input('passport_info', []))) {
                    $media->delete();
                }
            }
        }

        $media = $user->passport_info->pluck('file_name')->toArray();

        foreach ($request->input('passport_info', []) as $file) {
            if (count($media) === 0 || !in_array($file, $media)) {
                $user->addMedia(storage_path('tmp/uploads/' . $file))->toMediaCollection('passport_info');
            }
        }

        if (count($user->insurance) > 0) {
            foreach ($user->insurance as $media) {
                if (!in_array($media->file_name, $request->input('insurance', []))) {
                    $media->delete();
                }
            }
        }

        $media = $user->insurance->pluck('file_name')->toArray();

        foreach ($request->input('insurance', []) as $file) {
            if (count($media) === 0 || !in_array($file, $media)) {
                $user->addMedia(storage_path('tmp/uploads/' . $file))->toMediaCollection('insurance');
            }
        }

        return redirect()->route('admin.members.index');
    }

    

    //show
    public function show(Request $request,$id)
    {
        abort_if(Gate::denies('user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

       $user = User::find($id);


        return view('admin.members.show', compact('user'));
    }

    //destroy
    public function destroy(User $user)
    {
        abort_if(Gate::denies('user_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->delete();

        return back();
    }

    public function massDestroy(MassDestroyUserRequest $request)
    {
        User::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
