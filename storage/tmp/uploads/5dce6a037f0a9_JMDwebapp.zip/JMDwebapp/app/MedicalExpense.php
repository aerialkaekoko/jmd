<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MedicalExpense extends Model
{
    protected $table = 'medical_expenses';
}
