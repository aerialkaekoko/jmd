<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Insurance extends Model
{
    use SoftDeletes;

    public $table = 'insurances';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'phone',
        'address',
        'created_at',
        'updated_at',
        'deleted_at',
        'company_name',
        'assistance_id',
    ];
    public function assistance()
    {
        return $this->belongsTo(Assistance::class, 'assistance_id');
    }
    public function userInsurances()
    {
        return $this->hasMany(UserInsurance::class, 'insurance_id', 'id');
    }
    public function users()
    {
        return $this->belongsToMany(User::class,'user_insurances');
    }
}