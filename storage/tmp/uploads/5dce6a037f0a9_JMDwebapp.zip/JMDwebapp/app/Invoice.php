<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $table = 'invoices';
    public function user()
    {
        return $this->belongsTo('App\User','user_id');
    }
    public function insurance()
    {
        return $this->belongsTo('App\Insurance','insurance_id');
    }
    public function medical_expenses()
    {
        return $this->hasMany('App\MedicalExpense','invoice_id');
    }
    public function hospital()
    {
        return $this->belongsTo('App\Hospital','hospital_id');
    }
}
