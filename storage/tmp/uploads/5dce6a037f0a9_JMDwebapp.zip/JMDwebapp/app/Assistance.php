<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Assistance extends Model
{
    use SoftDeletes;

    public $table = 'assistances';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'email',
        'phone',
        'address',
        'created_at',
        'updated_at',
        'deleted_at',
        'assistance_name',
    ];
    public function insurances()
    {
        return $this->hasMany(Insurance::class, 'assistance_id', 'id');
    }

    public function userInsurances()
    {
        return $this->hasMany(UserInsurance::class, 'assistance_id', 'id');
    }
}