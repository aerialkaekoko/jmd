<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Spatie\MediaLibrary\Models\Media;
use App\Hospital;
use App\Doctor;
use App\User;

class Medical extends Model implements HasMedia
{
    use SoftDeletes, HasMediaTrait;

    public $table = 'medicals';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'disease_name',
        'manufacturer',
        'hospital_id',
        'member_id',
        'doctor_id',
        'created_at',
        'updated_at',
        'deleted_at',        
    ];


    public function hospitals()
    {
        return $this->belongsTo('App\Hospital','hospital_id');
    }

    public function doctors()
    {
        return $this->belongsTo('App\Doctor','doctor_id');
    }

    public function user()
    {
        return $this->belongsTo('App\User','user_id');
    }
}
