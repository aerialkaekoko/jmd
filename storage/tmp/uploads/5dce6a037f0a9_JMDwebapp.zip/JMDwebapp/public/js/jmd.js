$(document).ready(function(){
    new Chart(document.getElementById("line-chart"), {
	  type: 'line',
	  data: {
	    labels: [1500,1600,1700,1750,1800,1850,1900,1950,1999,2050],
	    datasets: [{ 
	        data: [86,114,106,106,107,111,133,221,783,2478],
	        label: "Thailand",
	        borderColor: "#3e95cd",
	        fill: false
	      }, { 
	        data: [282,350,411,502,635,809,947,1402,3700,5267],
	        label: "Myanmar",
	        borderColor: "#8e5ea2",
	        fill: false
	      }, { 
	        data: [168,170,178,190,203,276,408,547,675,734],
	        label: "Vietnam",
	        borderColor: "#3cba9f",
	        fill: false
	      },
	    ]
	  },
	  options: {
	    title: {
	      display: true,
	      text: 'World population per region (in millions)'
	    }
	  }
	});

	new Chart(document.getElementById("bar-chart-grouped"), {
	    type: 'bar',
	    data: {
	      labels: ["2015", "2016", "2017", "2018", "2019"],
	      datasets: [
	        {
	          label: "Profit",
	          backgroundColor: "#3e95cd",
	          data: [1333,2000,1783,2478,3478]
	        }, {
	          label: "Loss",
	          backgroundColor: "#8e5ea2",
	          data: [408,247,675,734,534]
	        }
	      ]
	    },
	    options: {
	      title: {
	        display: true,
	        text: 'Population growth (millions)'
	      }
	    }
	});

	new Chart(document.getElementById("doughnut-chart"), {
	    type: 'doughnut',
	    data: {
	      labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
	      datasets: [
	        {
	          label: "Population (millions)",
	          backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
	          data: [2478,5267,734,784,433]
	        }
	      ]
	    },
	    options: {
	      title: {
	        display: true,
	        text: 'Predicted world population (millions) in 2050'
	      }
	    }
	});

	new Chart(document.getElementById("bar-chart-grouped1"), {
	    type: 'bar',
	    data: {
	      labels: ["January", "February", "March","April","May", "June","July", "August", "September", "October","November", "December"],
	      datasets: [
	        {
	          label: "Profit",
	          backgroundColor: "#3e95cd",
	          data: [1333,2000,1783,2478,1333,2000,1783,2478,1333,2000,1783,2478]
	        }
	      ]
	    },
	    options: {
	      title: {
	        display: true,
	        text: 'Population growth (millions)'
	      }
	    }
	});

 });


//Dashboard Calendar
$(function(){
  $("#container").simpleCalendar();
});

$("#container").simpleCalendar({
  // event dates
  events: ['2019-11-04','2019-11-15','2019-11-21','2019-11-09'],
  // event info to show
  eventsInfo: ['Event 1','Event 2','Event 3','Event 4']
});

$("#container").simpleCalendar({
  minDate: "YYYY-MM-DD",
  maxDate: "YYYY-MM-DD",
});

$("#container").simpleCalendar({
  months: ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'],
  days: ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'],

});

$("#container").simpleCalendar({
  selectCallback: function (selDate) { }, 
  insertCallback: function () { }

});