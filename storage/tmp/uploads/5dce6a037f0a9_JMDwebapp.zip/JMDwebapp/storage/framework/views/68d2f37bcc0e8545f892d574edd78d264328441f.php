<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.assistance.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.assistances.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('assistance_name') ? 'has-error' : ''); ?>">
                <label for="assistance_name"><?php echo e(trans('cruds.assistance.fields.assistance_name')); ?>*</label>
                <input type="text" id="assistance_name" name="assistance_name" class="form-control" value="<?php echo e(old('assistance_name', isset($assistance) ? $assistance->assistance_name : '')); ?>" required>
                <?php if($errors->has('assistance_name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('assistance_name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.assistance.fields.assistance_name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="email"><?php echo e(trans('cruds.assistance.fields.email')); ?></label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email', isset($assistance) ? $assistance->email : '')); ?>">
                <?php if($errors->has('email')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('email')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.assistance.fields.email_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                <label for="phone"><?php echo e(trans('cruds.assistance.fields.phone')); ?></label>
                <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone', isset($assistance) ? $assistance->phone : '')); ?>">
                <?php if($errors->has('phone')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('phone')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.assistance.fields.phone_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <label for="address"><?php echo e(trans('cruds.assistance.fields.address')); ?></label>
                <input type="text" id="address" name="address" class="form-control" value="<?php echo e(old('address', isset($assistance) ? $assistance->address : '')); ?>">
                <?php if($errors->has('address')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('address')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.assistance.fields.address_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/assistances/create.blade.php ENDPATH**/ ?>