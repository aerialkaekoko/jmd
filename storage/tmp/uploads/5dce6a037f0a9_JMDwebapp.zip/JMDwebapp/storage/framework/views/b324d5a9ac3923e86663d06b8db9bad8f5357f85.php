<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.doctor.title')); ?>

    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->name); ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.hospital_id')); ?>

                        </th>
                        <td>
                            <?php echo e($hospital_name); ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.specialist')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->specialist); ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.qualification')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->qualification); ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.schedule')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->schedule); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.country')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->country); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.address')); ?>

                        </th>
                        <td>
                            <?php echo e($doctor->address); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.contact')); ?>

                        </th>
                        <td>
                            <?php echo $doctor->contact; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.doctors.fields.doctors_images')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $doctor->doctors_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($media->getUrl()); ?>" target="_blank">
                                    <img src="<?php echo e($media->getUrl('thumb')); ?>" width="50px" height="50px">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <a style="margin-top:20px;" class="btn btn-default" href="<?php echo e(url()->previous()); ?>">
                <?php echo e(trans('global.back_to_list')); ?>

            </a>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/doctors/show.blade.php ENDPATH**/ ?>