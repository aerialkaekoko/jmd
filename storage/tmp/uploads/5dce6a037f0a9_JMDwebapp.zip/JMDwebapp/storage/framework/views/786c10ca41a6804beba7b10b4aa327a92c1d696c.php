<?php $__env->startComponent('app_settings::input_group', compact('field')); ?>

    <textarea type="<?php echo e($field['type']); ?>"
              name="<?php echo e($field['name']); ?>"
              <?php if( $placeholder = Arr::get($field, 'placeholder') ): ?>
              placeholder="<?php echo e($placeholder); ?>"
              <?php endif; ?>
              <?php if( $rows = Arr::get($field, 'rows') ): ?>
              rows="<?php echo e($rows); ?>"
              <?php endif; ?>
              <?php if( $cols = Arr::get($field, 'cols') ): ?>
              cols="<?php echo e($cols); ?>"
              <?php endif; ?>
              class="<?php echo e(Arr::get( $field, 'class', config('app_settings.input_class', 'form-control'))); ?>"
              <?php if( $styleAttr = Arr::get($field, 'style')): ?> style="<?php echo e($styleAttr); ?>" <?php endif; ?>
              id="<?php echo e(Arr::get($field, 'name')); ?>"
    ><?php echo e(old($field['name'], \setting($field['name']))); ?></textarea>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/vendor/qcod/laravel-app-settings/src/resources/views/fields/textarea.blade.php ENDPATH**/ ?>