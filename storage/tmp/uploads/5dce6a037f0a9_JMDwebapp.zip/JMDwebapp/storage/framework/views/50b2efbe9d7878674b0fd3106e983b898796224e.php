<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.news.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.news.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                <label for="title"><?php echo e(trans('cruds.news.fields.title')); ?></label>
                <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title', isset($news) ? $news->title : '')); ?>">
                <?php if($errors->has('title')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('title')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.news.fields.title_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.news.fields.description')); ?></label>
                <textarea id="description" name="description" class="form-control ckeditor"><?php echo e(old('description', isset($news) ? $news->description : '')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('description')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.news.fields.description_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('news_images') ? 'has-error' : ''); ?>">
                <label for="news_images"><?php echo e(trans('cruds.news.fields.news_images')); ?></label>
                <div class="needsclick dropzone" id="news_images-dropzone">

                </div>
                <?php if($errors->has('news_images')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('news_images')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.news.fields.news_images_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    var uploadedNewsImagesMap = {}
Dropzone.options.newsImagesDropzone = {
    url: '<?php echo e(route('admin.news.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="news_images[]" value="' + response.name + '">')
      uploadedNewsImagesMap[file.name] = response.name
    },
    removedfile: function (file) {
      console.log(file)
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedNewsImagesMap[file.name]
      }
      $('form').find('input[name="news_images[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($news) && $news->news_images): ?>
      var files =
        <?php echo json_encode($news->news_images); ?>

          for (var i in files) {
          var file = files[i]
          this.options.addedfile.call(this, file)
          this.options.thumbnail.call(this, file, file.url)
          file.previewElement.classList.add('dz-complete')
          $('form').append('<input type="hidden" name="news_images[]" value="' + file.file_name + '">')
        }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/news/create.blade.php ENDPATH**/ ?>