<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    JMD APPLICATION
                </div>

                <div class="card-body">
                   <!--  <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in! -->
                    <div class="row">
                        <div class="col-lg-6">
                            <h2>Profit & Loss Statement</h2>
                            <canvas id="bar-chart-grouped" width="800" height="450"></canvas>
                        </div>
                        <div class="col-lg-6">
                            <h2>Member Statement</h2>
                            <canvas id="line-chart" width="800" height="450"></canvas>
                        </div>
                    </div>
                    <br/><br/><br/>

                    <div class="row">
                        <div class="col-lg-6">
                            <h2>Chart Three</h2>
                            <canvas id="doughnut-chart" width="800" height="450"></canvas>
                        </div>
                        <div class="col-lg-6">
                            <h2>Profit / Loss Statement</h2>
                            <canvas id="bar-chart-grouped1" width="800" height="450"></canvas>
                        </div>
                       
                    </div>
                    <hr/>

                    <div class="row">
                        <div class="col-lg-6">
                             <h2>Event Calendar</h2><br/>
                            <div id="container"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/home.blade.php ENDPATH**/ ?>