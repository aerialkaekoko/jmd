<?php $__env->startSection('content'); ?>
<div class="content">

    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.userInsurance.title_singular')); ?>

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route("admin.user-insurances.store")); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
                            <label for="user"><?php echo e(trans('cruds.userInsurance.fields.user')); ?>*</label>
                            <select name="user_id" id="user" class="form-control select2" required>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((isset($userInsurance) && $userInsurance->user ? $userInsurance->user->id : old('user_id')) == $id ? 'selected' : ''); ?>><?php echo e($user); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('user_id')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('user_id')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('assistance_id') ? 'has-error' : ''); ?>">
                            <label for="assistance"><?php echo e(trans('cruds.userInsurance.fields.assistance')); ?>*</label>
                            <select name="assistance_id" id="assistance" class="form-control select2" required>
                                <?php $__currentLoopData = $assistances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $assistance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((isset($userInsurance) && $userInsurance->assistance ? $userInsurance->assistance->id : old('assistance_id')) == $id ? 'selected' : ''); ?>><?php echo e($assistance); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('assistance_id')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('assistance_id')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('insurance_id') ? 'has-error' : ''); ?>">
                            <label for="insurance"><?php echo e(trans('cruds.userInsurance.fields.insurance')); ?>*</label>
                            <select name="insurance_id" id="insurance" class="form-control select2" required>
                                <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((isset($userInsurance) && $userInsurance->insurance ? $userInsurance->insurance->id : old('insurance_id')) == $id ? 'selected' : ''); ?>><?php echo e($insurance); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('insurance_id')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('insurance_id')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' : ''); ?>">
                            <label for="amount"><?php echo e(trans('cruds.userInsurance.fields.amount')); ?>*</label>
                            <input type="number" id="amount" name="amount" class="form-control" value="<?php echo e(old('amount', isset($userInsurance) ? $userInsurance->amount : '')); ?>" step="0.01" required>
                            <?php if($errors->has('amount')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('amount')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('cruds.userInsurance.fields.amount_helper')); ?>

                            </p>
                        </div>
                        <div>
                            <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
                        </div>
                    </form>


                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#assistance').on('change',function(){
                var assistance_id = $(this).val();
                $.ajax({
                    method : 'GET',
                    url : '/admin/get_insurances/'+assistance_id,
                    success : function(data){
                        if (data.success) {
                            $('#insurance option').remove();
                            $("#insurance").append('<option value="">Choose</option>');
                            $.each(data.data, function(){
                                    $("#insurance").append('<option value="'+ this.id +'">'+ this.company_name +'</option>');
                            });
                        }
                    }
                });
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/user-insurances/create.blade.php ENDPATH**/ ?>