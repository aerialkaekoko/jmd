<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.invoices.title_singular')); ?>

        </div>
        <div class="card-body">
            <form action="<?php echo e(route("admin.invoices.update",[$invoice->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Invoice Code">Invoice Code *:</label>
                            <input type="text" class="form-control" name="invoice_code" id="invoice_code" placeholder="Enter Invoice Code" value="<?php echo e($invoice->invoice_code); ?>" >
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Reference No">Reference No *:</label>
                            <input type="text" class="form-control" name="reference_no" id="reference_no" placeholder="Enter Reference No" value="<?php echo e($invoice->reference_no); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="User">User *:</label>
                            <select class="form-control select2" id="user" name="user_id" >
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((isset($invoice) && $invoice->user ? $invoice->user->id : old('user_id')) == $id ? 'selected' : ''); ?>><?php echo e($user); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Hospital">Hospital *:</label>
                            <select class="form-control select2" id="hospital" name="hospital_id" >
                                <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((isset($invoice) && $invoice->hospital ? $invoice->hospital->id : old('hospital_id')) == $id ? 'selected' : ''); ?>><?php echo e($hospital); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Payment Type">Payment Type *:</label>
                            <select class="form-control" name="payment_type" id="payment_type" >
                                <option value="">Choose Payment Type</option>
                                <?php if($invoice->receive_type == 1): ?>
                                    <option value="1" selected>Insurance</option>
                                    <option value="2">Cash</option>
                                <?php else: ?>
                                    <option value="1">Insurance</option>
                                    <option value="2" selected>Cash</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 byInsurance">
                        <div class="form-group">
                            <label for="Insurance">Insurance *:</label>
                            <select class="form-control select2" name="insurance_id" id="insurance">
                                <option value="">Choose Insurance</option>
                                <?php $__currentLoopData = $invoice->user->insurances()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($insurance->id); ?>" <?php echo e((isset($invoice) && $invoice->insurance ? $invoice->insurance->id : old('insurance_id')) == $insurance->id ? 'selected' : ''); ?>><?php echo e($insurance->company_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="repeater card p-4">
                    <h4>Expenses</h4>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="alert"></div>
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th width="60%">Expense Type</th>
                                        <th>Amount</th>
                                        <th>
                                                <input data-repeater-create type="button" class="btn btn-sm btn-primary" value="Add Expense"/>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody data-repeater-list="expense_group">
                                    <?php if($medical_expenses->count() > 0): ?>
                                        <?php $__currentLoopData = $medical_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr data-repeater-item>
                                                <td>
                                                    <input type="text" name="expense_type" id="expense_type" class="form-control" value="<?php echo e($value->expense_type); ?>" placeholder="Enter Expense Type">
                                                </td>
                                                <td>
                                                    <input type="text" name="expense_amount" id="expense_amount" class="form-control text-right" value="<?php echo e($value->expense_amount); ?>">
                                                </td>
                                                <td>
                                                    <input type="hidden" name="expense_id" id="expense_id" value="<?php echo e($value->id); ?>">
                                                    <input data-repeater-delete type="button" class="btn btn-sm btn-danger" name="expense_delete" data-expense_id=<?php echo e($value->id); ?> value="x"/>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr data-repeater-item>
                                            <td>
                                                <input type="text" name="expense_type" id="expense_type" class="form-control" value="" placeholder="Enter Expense Type">
                                            </td>
                                            <td>
                                                <input type="text" name="expense_amount" id="expense_amount" class="form-control text-right" value="0">
                                            </td>
                                            <td>
                                                <input type="hidden" name="expense_id" id="expense_id" value="">
                                                <input data-repeater-delete type="button"  class="btn btn-sm btn-danger" value="x"/>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-right">
                        <input type="submit" value="Update Invoice" class="btn btn-md btn-primary">
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/jquery-repeater.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('.repeater').repeater({
            initEmpty: false,
            defaultValues: {
                'expense_amount': 0,
                'expense_delete' : 'x',
            },
            show: function () {
                $(this).slideDown();
            },
            // hide: function (deleteElement) {
            //     if(confirm('Are you sure you want to delete this element?')) {
            //         $(this).slideUp(deleteElement);
            //     }
            // },
            isFirstItemUndeletable: false
        });
        if ($('#payment_type').val() == 1) {
            $('.byInsurance').show();
        } else {
            $('.byInsurance').hide();
        }
        
        $('#payment_type').on('change',function(){
            if ($(this).val() == 1) {
                $('.byInsurance').show();
                $('#assistance_id').attr('required',true);
                $('#insurance_id').attr('required',true);
            } else {
                $('.byInsurance').hide();
                $('#assistance_id').attr('required',false);
                $('#insurance_id').attr('required',false);
            }
        });
        $('#user').on('change',function(){
            var user_id = $(this).val();
            $.ajax({
                method : 'GET',
                url : '/admin/get_user_insurance/'+user_id,
                success : function(data){
                    $('#insurance option').remove();
                    $("#insurance").append('<option value="">Choose</option>');
                    $.each(data.data, function(){
                            $("#insurance").append('<option value="'+ this.id +'">'+ this.company_name +'</option>');
                    });
                }
            })
        });
       
        });
        function expenseDelete(index,e) {
            // if(confirm('Are you sure you want to delete this element?')) {
                var expense_id = $('#expense_id'+index).val();
                $.ajax({
                    method : 'GET',
                    url :'/admin/delete_expense/'+expense_id,
                    success : function(data){
                        if (data.success) {
                            $('.alert').html("<div class='alert alert-success' role='alert'>Delete Successfully</div>");
                        }
                    }
                })
            // }
           
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/invoices/edit.blade.php ENDPATH**/ ?>