<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
            <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.insurance.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.insurances.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('company_name') ? 'has-error' : ''); ?>">
                <label for="company_name"><?php echo e(trans('cruds.insurance.fields.company_name')); ?>*</label>
                <input type="text" id="company_name" name="company_name" class="form-control" value="<?php echo e(old('company_name', isset($insurance) ? $insurance->company_name : '')); ?>" required>
                <?php if($errors->has('company_name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('company_name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.insurance.fields.company_name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                <label for="phone"><?php echo e(trans('cruds.insurance.fields.phone')); ?></label>
                <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone', isset($insurance) ? $insurance->phone : '')); ?>">
                <?php if($errors->has('phone')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('phone')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.insurance.fields.phone_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <label for="address"><?php echo e(trans('cruds.insurance.fields.address')); ?></label>
                <input type="text" id="address" name="address" class="form-control" value="<?php echo e(old('address', isset($insurance) ? $insurance->address : '')); ?>">
                <?php if($errors->has('address')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('address')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.insurance.fields.address_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('assistance_id') ? 'has-error' : ''); ?>">
                <label for="assistance"><?php echo e(trans('cruds.insurance.fields.assistance')); ?>*</label>
                <select name="assistance_id" id="assistance" class="form-control select2" required>
                    <?php $__currentLoopData = $assistances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $assistance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($insurance) && $insurance->assistance ? $insurance->assistance->id : old('assistance_id')) == $id ? 'selected' : ''); ?>><?php echo e($assistance); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('assistance_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('assistance_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/insurances/create.blade.php ENDPATH**/ ?>