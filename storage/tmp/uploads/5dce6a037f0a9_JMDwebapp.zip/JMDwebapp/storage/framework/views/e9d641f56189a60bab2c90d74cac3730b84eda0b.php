<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
        <img class="f_logo" src="/storage/<?php echo e(AppSettings::get('logo')); ?>" alt="LOGO JMD" title="LOGO JMD">
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.home")); ?>" class="nav-link">
                        <p>
                            <i class="fas fa-fw fa-tachometer-alt">
                
                            </i>
                            <span><?php echo e(trans('global.dashboard')); ?></span>
                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is('admin/permissions*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/roles*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/users*') ? 'menu-open' : ''); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw fas fa-users">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.userManagement.title')); ?></span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.permission.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-briefcase">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.role.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-user">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.user.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
               
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.news.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/news') || request()->is('admin/news/*') ? 'active' : ''); ?>">
                        <i class="fas fa-newspaper"></i>
                        <p>
                            <span><?php echo e(trans('cruds.news.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hospitals_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.hospitals.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/hospitals/*') ? 'active' : ''); ?>">
                        <i class="fas fa-hospital"></i>
                        <p>
                            <span><?php echo e(trans('cruds.hospitals.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctors_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.doctors.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/doctors/*') ? 'active' : ''); ?>">
                        <i class="fas fa-user-md"></i>
                        <p>
                            <span><?php echo e(trans('cruds.doctors.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('medicals_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.medicals.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/medicals/*') ? 'active' : ''); ?>">
                        <i class="fas fa-briefcase-medical"></i>
                        <p>
                            <span><?php echo e(trans('cruds.medicals.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('members')): ?>
                <li class="nav-item">
                    <a class="nav-link " href="<?php echo e(route("admin.members.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions*') || request()->is('admin/members/*') ? 'active' : ''); ?>">
                        <i class="fas fa-users-cog"></i>
                        <p>
                            <span><?php echo e(trans('cruds.members.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
                <li class="nav-item">
                <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="nav-link " class="<?php echo e(request()->is('admin/user-alerts') || request()->is('admin/user-alerts/*') ? 'active' : ''); ?> nav-item">
                   <i class="fa-fw fas fa-bell"></i>
                   <p><span><?php echo e(trans('cruds.userAlert.title')); ?></span></p>
                        
                </a>
                </li>
            <?php endif; ?>
            
             <?php ($unread = \App\QaTopic::unreadCount()); ?>
             <li class="nav-item">
                <a class="nav-link " href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is('admin/messenger') || request()->is('admin/messenger/*') ? 'active' : ''); ?>">
                   <i class="fa-fw fa fa-envelope"></i>
                     <p>
                        <span><?php echo e(trans('global.messages')); ?></span>
                        <?php if($unread > 0): ?>
                            <strong>( <?php echo e($unread); ?> )</strong>
                        <?php endif; ?>
                       </p> 
                    </a>
             </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assistance_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.assistances.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/assistances/*') ? 'active' : ''); ?>">
                        <i class="fas fa-hands-helping"></i>
                        <p>
                            <span><?php echo e(trans('cruds.assistance.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insurance_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.insurances.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/insurances/*') ? 'active' : ''); ?>">
                        <i class="fas fa-building"></i>
                        <p>
                            <span><?php echo e(trans('cruds.insurance.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_insurance_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.user-insurances.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/user_insurances/*') ? 'active' : ''); ?>">
                        <i class="fas fa-user"></i>
                        <p>
                            <span><?php echo e(trans('cruds.userInsurance.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_access')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.invoices.index")); ?>"
                        class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/invoices/*') ? 'active' : ''); ?>">
                        <i class="fas fa-file-invoice"></i>
                        <p>
                            <span><?php echo e(trans('cruds.invoices.title')); ?></span>
                        </p>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setting')): ?>
                <li class="nav-item">
                     <a href="<?php echo e(url("settings")); ?>"
                         class="nav-link <?php echo e(request()->is('/settings') || request()->is('/settings/*') ? 'active' : ''); ?>">
                         <i class="fas fa-cogs"></i>
                         <p>
                             <span><?php echo e(trans('cruds.setting.title')); ?></span>
                         </p>
                     </a>
                 </li> 
                 <?php endif; ?>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt">

                            </i>
                            <span><?php echo e(trans('global.logout')); ?></span>
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/partials/menu.blade.php ENDPATH**/ ?>