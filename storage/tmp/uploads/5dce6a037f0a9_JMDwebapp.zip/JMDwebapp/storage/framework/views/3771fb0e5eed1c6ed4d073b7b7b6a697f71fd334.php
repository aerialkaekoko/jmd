<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.members.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.members.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <!-- refno  -->
            <div class="form-group <?php echo e($errors->has('ref_no') ? 'has-error' : ''); ?>">
                <label for="ref_no"><?php echo e(trans('cruds.members.fields.ref_no')); ?>*</label>
                <input type="text" id="ref_no" name="ref_no" class="form-control"
                    value="<?php echo e(old('ref_no', isset($user) ? $user->ref_no : '')); ?>">
                <?php if($errors->has('ref_no')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('ref_no')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.ref_no_helper')); ?>

                </p>
            </div>
            <!-- end refno -->

             <!-- //family_name  -->
            <div class="form-group <?php echo e($errors->has('family_name') ? 'has-error' : ''); ?>">
                <label for="family_name"><?php echo e(trans('cruds.members.fields.fname')); ?></label>
                <input type="text" id="family_name" name="family_name" class="form-control"
                    value="<?php echo e(old('family_name', isset($user) ? $user->family_name : '')); ?>">
                <?php if($errors->has('family_name')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('family_name')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.fname_helper')); ?>

                </p>
            </div>
            <!-- end//family_name  -->
            
            <!-- name -->
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.members.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control"
                    value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('name')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.name_helper')); ?>

                </p>
            </div>
            <!-- endname -->

            <!-- email -->
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="email"><?php echo e(trans('cruds.members.fields.email')); ?>*</label>
                <input type="email" id="email" name="email" class="form-control"
                    value="<?php echo e(old('email', isset($user) ? $user->email : '')); ?>" required>
                <?php if($errors->has('email')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('email')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.email_helper')); ?>

                </p>
            </div>
            <!-- endemail -->

          

            <!-- password -->
            <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                <label for="password"><?php echo e(trans('cruds.members.fields.password')); ?></label>
                <input type="password" id="password" name="password" class="form-control" required>
                <?php if($errors->has('password')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('password')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.password_helper')); ?>

                </p>
            </div>
            
             
             
            

             <!-- gender -->
            <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                <label for="gender"><?php echo e(trans('cruds.members.fields.gender')); ?></label>
                <select id="gender" name="gender" class="form-control">
                    <option value="" disabled><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\User::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('gender', 'Select Gender') === (string)$key ? 'selected' : ''); ?>><?php echo e($label); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('gender')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('gender')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.gender_helper')); ?>

                </p>
            </div>
            <!-- end gender -->

            
            <!-- address -->
            <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <label for="address"><?php echo e(trans('cruds.members.fields.address')); ?>*</label>
                <textarea id="address" name="address"
                    class="form-control"><?php echo e(old('address', isset($user) ? $user->address : '')); ?></textarea>
                <?php if($errors->has('address')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('address')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.address_helper')); ?>

                </p>
            </div>
            <!-- end address -->


            <!-- phone -->
            <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                <label for="phone"><?php echo e(trans('cruds.user.fields.phone')); ?>*</label>
                <input type="text" id="phone" name="phone" class="form-control"
                    value="<?php echo e(old('phone', isset($user) ? $user->Phone : '')); ?>">
                <?php if($errors->has('phone')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('phone')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.phone_helper')); ?>

                </p>
            </div>
            <!--end phone -->

            <!-- passport -->
            <div class="form-group <?php echo e($errors->has('passport') ? 'has-error' : ''); ?>">
                <label for="passport"><?php echo e(trans('cruds.user.fields.passport')); ?>*</label>
                <input type="text" id="passport" name="passport" class="form-control"
                    value="<?php echo e(old('passport', isset($user) ? $user->passport : '')); ?>">
                <?php if($errors->has('passport')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('passport')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.passport_helper')); ?>

                </p>
            </div>
            <!-- endpassport -->

            <!-- passport info -->
            <div class="form-group <?php echo e($errors->has('passport_info') ? 'has-error' : ''); ?>">
                <label for="passport_info"><?php echo e(trans('cruds.user.fields.passport_info')); ?></label>
                <div class="needsclick dropzone" id="passport_info-dropzone">
            
                </div>
                <?php if($errors->has('passport_info')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('passport_info')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.passport_info_helper')); ?>

                </p>
            </div>
            <!-- end passport info -->

            <!-- insurance -->
            <div class="form-group <?php echo e($errors->has('insurance') ? 'has-error' : ''); ?>">
                <label for="insurance"><?php echo e(trans('cruds.user.fields.insurance')); ?></label>
                <div class="needsclick dropzone" id="insurance-dropzone">
            
                </div>
                <?php if($errors->has('insurance')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('insurance')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.members.fields.insurance_helper')); ?>

                </p>
            </div>
            <!-- insurance -->

            
            
        <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    var uploadedPassportInfoMap = {}
Dropzone.options.passportInfoDropzone = {
    url: '<?php echo e(route('admin.members.storeMedia')); ?>',
    maxFilesize: 5, // MB
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 5
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="passport_info[]" value="' + response.name + '">')
      uploadedPassportInfoMap[file.name] = response.name
    },
    removedfile: function (file) {
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedPassportInfoMap[file.name]
      }
      $('form').find('input[name="passport_info[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($user) && $user->passport_info): ?>
          var files =
            <?php echo json_encode($user->passport_info); ?>

              for (var i in files) {
              var file = files[i]
              this.options.addedfile.call(this, file)
              file.previewElement.classList.add('dz-complete')
              $('form').append('<input type="hidden" name="passport_info[]" value="' + file.file_name + '">')
            }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<script>
    var uploadedInsuranceMap = {}
Dropzone.options.insuranceDropzone = {
    url: '<?php echo e(route('admin.members.storeMedia')); ?>',
    maxFilesize: 6, // MB
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 6
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="insurance[]" value="' + response.name + '">')
      uploadedInsuranceMap[file.name] = response.name
    },
    removedfile: function (file) {
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedInsuranceMap[file.name]
      }
      $('form').find('input[name="insurance[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($user) && $user->insurance): ?>
          var files =
            <?php echo json_encode($user->insurance); ?>

              for (var i in files) {
              var file = files[i]
              this.options.addedfile.call(this, file)
              file.previewElement.classList.add('dz-complete')
              $('form').append('<input type="hidden" name="insurance[]" value="' + file.file_name + '">')
            }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/members/create.blade.php ENDPATH**/ ?>