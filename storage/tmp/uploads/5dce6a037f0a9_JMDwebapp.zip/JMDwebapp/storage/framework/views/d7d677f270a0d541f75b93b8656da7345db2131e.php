<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.invoices.title_singular')); ?>

        </div>
        <div class="card-body">
            <form action="<?php echo e(route("admin.invoices.store")); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Invoice Code">Invoice Code *:</label>
                            <input type="text" class="form-control" name="invoice_code" id="invoice_code" placeholder="Enter Invoice Code" >
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Reference No">Reference No *:</label>
                            <input type="text" class="form-control" name="reference_no" id="reference_no" placeholder="Enter Reference No" >
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="User">User *:</label>
                            <select class="form-control select2" id="user" name="user_id" >
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" ><?php echo e($user); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Hospital">Hospital *:</label>
                            <select class="form-control select2" id="hospital" name="hospital_id" >
                                <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" ><?php echo e($hospital); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="Payment Type">Payment Type *:</label>
                            <select class="form-control" name="payment_type" id="payment_type" >
                                <option value="">Choose Payment Type</option>
                                <option value="1">Insurance</option>
                                <option value="2">Cash</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 byInsurance">
                        <div class="form-group">
                            <label for="Insurance">Insurance *:</label>
                            <select class="form-control select2" name="insurance_id" id="insurance">
                                <option value="">Choose Insurance</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="repeater">
                    <h4>Expenses</h4>
                    <div class="row">
                        <div class="col-md-8">
                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th width="60%">Expense Type</th>
                                        <th>Amount</th>
                                        <th>
                                                <input data-repeater-create type="button" class="btn btn-sm btn-primary" value="Add Expense"/>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody data-repeater-list="expense_group">
                                    <tr data-repeater-item>
                                        <td>
                                            <input type="text" name="expense_type" id="expense_type" class="form-control" placeholder="Enter Expense Type">
                                        </td>
                                        <td>
                                            <input type="text" name="expense_amount" id="expense_amount" class="form-control text-right" value="0">
                                        </td>
                                        <td>
                                            <input data-repeater-delete type="button" class="btn btn-sm btn-danger" value="x"/>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-right">
                        <input type="submit" value="Add Invoice" class="btn btn-md btn-primary">
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/jquery-repeater.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('.repeater').repeater({
            initEmpty: false,
            defaultValues: {
                'expense_amount': 0,
            },
            show: function () {
                $(this).slideDown();
            },
            hide: function (deleteElement) {
                if(confirm('Are you sure you want to delete this element?')) {
                    $(this).slideUp(deleteElement);
                }
            },
            isFirstItemUndeletable: true
        });
        $('.byInsurance').hide();
        $('#payment_type').on('change',function(){
            if ($(this).val() == 1) {
                $('.byInsurance').show();
                $('#assistance_id').attr('required',true);
                $('#insurance_id').attr('required',true);
            } else {
                $('.byInsurance').hide();
                $('#assistance_id').attr('required',false);
                $('#insurance_id').attr('required',false);
            }
        });
        $('#user').on('change',function(){
            var user_id = $(this).val();
            console.log('user_id', user_id);
            $.ajax({
                method : 'GET',
                url : '/admin/get_user_insurance/'+user_id,
                success : function(data){
                    $('#insurance option').remove();
                    $("#insurance").append('<option value="">Choose</option>');
                    $.each(data.data, function(){
                            $("#insurance").append('<option value="'+ this.id +'">'+ this.company_name +'</option>');
                    });
                }
            })
        });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kmt/Desktop/JMD/jmdwebapp/resources/views/admin/invoices/create.blade.php ENDPATH**/ ?>