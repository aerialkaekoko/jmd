@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.doctor.title') }}
    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.id') }}
                        </th>
                        <td>
                            {{ $doctor->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.name') }}
                        </th>
                        <td>
                            {{ $doctor->name }}
                        </td>
                    </tr>
                     <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.hospital_id') }}
                        </th>
                        <td>
                            {{ $hospital_name }}
                        </td>
                    </tr>
                     <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.specialist') }}
                        </th>
                        <td>
                            {{ $doctor->specialist }}
                        </td>
                    </tr>
                     <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.qualification') }}
                        </th>
                        <td>
                            {{ $doctor->qualification }}
                        </td>
                    </tr>
                     <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.schedule') }}
                        </th>
                        <td>
                            {{ $doctor->schedule }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.country') }}
                        </th>
                        <td>
                            {{ $doctor->country }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.address') }}
                        </th>
                        <td>
                            {{ $doctor->address }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.contact') }}
                        </th>
                        <td>
                            {!! $doctor->contact !!}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.doctors.fields.doctors_images') }}
                        </th>
                        <td>
                            @foreach($doctor->doctors_images as $key => $media)
                                <a href="{{ $media->getUrl() }}" target="_blank">
                                    <img src="{{ $media->getUrl('thumb') }}" width="50px" height="50px">
                                </a>
                            @endforeach
                        </td>
                    </tr>
                </tbody>
            </table>
            <a style="margin-top:20px;" class="btn btn-default" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>


    </div>
</div>
@endsection