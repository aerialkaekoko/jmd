@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.create') }} {{ trans('cruds.medicals.title_singular') }}
    </div>

    <div class="card-body">
        <form action="{{ route("admin.medicals.store") }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{ $errors->has('disease_name') ? 'has-error' : '' }}">
                <label for="disease_name">{{ trans('cruds.medicals.fields.disease_name') }}</label>
                <input type="text" id="disease_name" name="disease_name" class="form-control" value="{{ old('disease_name', isset($medicals) ? $medicals->disease_name : '') }}">
                @if($errors->has('disease_name'))
                    <p class="help-block">
                        {{ $errors->first('disease_name') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.medicals.fields.name_helper') }}
                </p>
            </div>

            <div class="form-group {{ $errors->has('manufacturer') ? 'has-error' : '' }}">
                <label for="manufacturer">{{ trans('cruds.medicals.fields.manufacturer') }}</label>
                <input type="text" id="manufacturer" name="manufacturer" class="form-control" value="{{ old('manufacturer', isset($medicals) ? $medicals->manufacturer : '') }}">
                @if($errors->has('manufacturer'))
                    <p class="help-block">
                        {{ $errors->first('manufacturer') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.medicals.fields.manufacturer_helper') }}
                </p>
            </div>
            {{-- 
            <div class="form-group">
                <label for="address">{{ trans('cruds.medicals.fields.hospital_id') }}</label>
                <select id="hospitals" name="hospital_id" class="form-control">
                    <option value="0">Select Hospital</option>
                    @foreach($hospitals as $hospital)
                        <option value="{{ $hospital->id }}"
                            {{ $hospital->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            --}}

            <div class="form-group {{ $errors->has('hospital_id') ? 'has-error' : '' }}">
                <label for="status">{{ trans('cruds.medicals.fields.hospital_id') }}*</label>
                <select name="hospital_id" id="hospital_id" class="form-control select2" required>
                    @foreach($hospitals as $id => $hospital)
                        <option value="{{ $id }}" {{ (isset($Hospital) && $Hospital->hospital ? $Hospital->hospital->id : old('hospital_id')) == $id ? 'selected' : '' }}>{{ $hospital }}</option>
                    @endforeach
                </select>
                @if($errors->has('hospital_id'))
                    <p class="help-block">
                        {{ $errors->first('hospital_id') }}
                    </p>
                @endif
            </div>

            <div class="form-group {{ $errors->has('doctor_id') ? 'has-error' : '' }}">
                <label for="status">{{ trans('cruds.medicals.fields.doctor_id') }}*</label>
                <select name="doctor_id" id="doctor_id" class="form-control select2" required>
                    @foreach($doctors as $id => $doctor)
                        <option value="{{ $id }}" {{ (isset($Doctor) && $Doctor->doctor ? $Doctor->doctor->id : old('doctor_id')) == $id ? 'selected' : '' }}>{{ $doctor }}</option>
                    @endforeach
                </select>
                @if($errors->has('doctor_id'))
                    <p class="help-block">
                        {{ $errors->first('doctor_id') }}
                    </p>
                @endif
            </div>

            <div class="form-group {{ $errors->has('user_id') ? 'has-error' : '' }}">
                <label for="status">{{ trans('cruds.medicals.fields.user_id') }}*</label>
                <select name="user_id" id="user_id" class="form-control select2" required>
                    @foreach($users as $id => $user)
                        <option value="{{ $id }}" {{ (isset($Doctor) && $Doctor->user ? $Doctor->user->id : old('user_id')) == $id ? 'selected' : '' }}>{{ $user }}</option>
                    @endforeach
                </select>
                @if($errors->has('user_id'))
                    <p class="help-block">
                        {{ $errors->first('user_id') }}
                    </p>
                @endif
            </div>

            <div>
                <input class="btn btn-primary" type="submit" value="{{ trans('global.save') }}">
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
    var uploadedHospitalsImagesMap = {}
Dropzone.options.medicalsImagesDropzone = {
    url: '{{ route('admin.medicals.storeMedia') }}',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "{{ csrf_token() }}"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="medicals_images[]" value="' + response.name + '">')
      uploadedHospitalsImagesMap[file.name] = response.name
    },
    removedfile: function (file) {
      console.log(file)
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedHospitalsImagesMap[file.name]
      }
      $('form').find('input[name="medicals_images[]"][value="' + name + '"]').remove()
    },
    init: function () {
@if(isset($medicals) && $medicals->medicals_images)
      var files =
        {!! json_encode($hospitals->hospitals_images) !!}
          for (var i in files) {
          var file = files[i]
          this.options.addedfile.call(this, file)
          this.options.thumbnail.call(this, file, file.url)
          file.previewElement.classList.add('dz-complete')
          $('form').append('<input type="hidden" name="hospitals_images[]" value="' + file.file_name + '">')
        }
@endif
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
@stop