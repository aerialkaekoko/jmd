@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.medicals.title_singular') }}
    </div>

    <div class="card-body">
        <form action="{{ route("admin.medicals.update", [$medical->id]) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="form-group {{ $errors->has('disease_name') ? 'has-error' : '' }}">
                <label for="disease_name">{{ trans('cruds.medicals.fields.disease_name') }}</label>
                <input type="text" id="disease_name" name="disease_name" class="form-control" value="{{ old('disease_name', isset($medical) ? $medical->disease_name : '') }}">
                @if($errors->has('disease_name'))
                    <p class="help-block">
                        {{ $errors->first('disease_name') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.medicals.fields.name_helper') }}
                </p>
            </div>            

            <div class="form-group {{ $errors->has('manufacturer') ? 'has-error' : '' }}">
                <label for="manufacturer">{{ trans('cruds.medicals.fields.manufacturer') }}</label>
                <input type="text" id="manufacturer" name="manufacturer" class="form-control" value="{{ old('name', isset($medical) ? $medical->manufacturer : '') }}">
                @if($errors->has('manufacturer'))
                    <p class="help-block">
                        {{ $errors->first('manufacturer') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.medicals.fields.manufacturer_helper') }}
                </p>
            </div>
            {{--
            <div class="form-group {{ $errors->has('hospital_id') ? 'has-error' : '' }}">
                <label for="hospitals">{{ trans('cruds.medicals.fields.hospital_id') }}*
                    <span class="btn btn-info btn-xs select-all">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all">{{ trans('global.deselect_all') }}</span></label>
                <select name="hospital_id[]" id="hospitals" class="form-control select2" multiple="multiple" required>
                    @foreach($hospitals as $id => $hospitals)
                        <option value="{{ $id }}" {{ (in_array($id, old('hospitals', [])) || isset($user) && $user->hospitals->contains($id)) ? 'selected' : '' }}>{{ $hospitals }}</option>
                    @endforeach
                </select>
                @if($errors->has('hospitals'))
                    <p class="help-block">
                        {{ $errors->first('hospitals') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.medicals.fields.hospital_helper') }}
                </p>
            </div>
            --}}

            <div class="form-group {{ $errors->has('hospital_id') ? 'has-error' : '' }}">
                <label for="hospitals">{{ trans('cruds.doctors.fields.hospital_id') }}*
                    <span class="btn btn-info btn-xs select-all">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all">{{ trans('global.deselect_all') }}</span></label>
                <select name="hospital_id" id="hospitals" class="form-control select" multiple="multiple" required>
                    @foreach($hospitals as $id => $hospitals)
                        <option value="{{ $id }}" {{ (in_array($id, old('hospitals', [])) || isset($user) && $user->hospitals->contains($id)) ? 'selected' : '' }}>{{ $hospitals }}</option>
                    @endforeach
                </select>
                @if($errors->has('hospitals'))
                    <p class="help-block">
                        {{ $errors->first('hospitals') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.doctors.fields.hospital_helper') }}
                </p>
            </div>

            <div class="form-group {{ $errors->has('doctor_id') ? 'has-error' : '' }}">
                <label for="doctors">{{ trans('cruds.doctors.fields.doctor_id') }}*
                    <span class="btn btn-info btn-xs select-all">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all">{{ trans('global.deselect_all') }}</span></label>
                <select name="doctor_id" id="doctors" class="form-control select" multiple="multiple" required>
                    @foreach($doctors as $id => $doctors)
                        <option value="{{ $id }}" {{ (in_array($id, old('doctors', [])) || isset($user) && $user->doctors->contains($id)) ? 'selected' : '' }}>{{ $doctors }}</option>
                    @endforeach
                </select>
                @if($errors->has('doctors'))
                    <p class="help-block">
                        {{ $errors->first('doctors') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.doctors.fields.doctor_helper') }}
                </p>
            </div>

            <div>
                <input class="btn btn-primary" type="submit" value="{{ trans('global.update') }}">
            </div>
        </form>


    </div>
</div>
@endsection