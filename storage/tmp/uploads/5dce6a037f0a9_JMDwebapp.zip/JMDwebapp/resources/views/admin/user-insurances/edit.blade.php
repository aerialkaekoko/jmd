@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-header">
                    {{ trans('global.edit') }} {{ trans('cruds.userInsurance.title_singular') }}
                </div>
                <div class="card-body">

                    <form action="{{ route("admin.user-insurances.update", [$userInsurance->id]) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-group {{ $errors->has('user_id') ? 'has-error' : '' }}">
                            <label for="user">{{ trans('cruds.userInsurance.fields.user') }}*</label>
                            <select name="user_id" id="user" class="form-control select2" required>
                                @foreach($users as $id => $user)
                                    <option value="{{ $id }}" {{ (isset($userInsurance) && $userInsurance->user ? $userInsurance->user->id : old('user_id')) == $id ? 'selected' : '' }}>{{ $user }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('user_id'))
                                <p class="help-block">
                                    {{ $errors->first('user_id') }}
                                </p>
                            @endif
                        </div>
                        <div class="form-group {{ $errors->has('assistance_id') ? 'has-error' : '' }}">
                            <label for="assistance">{{ trans('cruds.userInsurance.fields.assistance') }}*</label>
                            <select name="assistance_id" id="assistance" class="form-control select2" required>
                                @foreach($assistances as $id => $assistance)
                                    <option value="{{ $id }}" {{ (isset($userInsurance) && $userInsurance->assistance ? $userInsurance->assistance->id : old('assistance_id')) == $id ? 'selected' : '' }}>{{ $assistance }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('assistance_id'))
                                <p class="help-block">
                                    {{ $errors->first('assistance_id') }}
                                </p>
                            @endif
                        </div>
                        <div class="form-group {{ $errors->has('insurance_id') ? 'has-error' : '' }}">
                            <label for="insurance">{{ trans('cruds.userInsurance.fields.insurance') }}*</label>
                            <select name="insurance_id" id="insurance" class="form-control select2" required>
                                @foreach($insurances as $id => $insurance)
                                    <option value="{{ $id }}" {{ (isset($userInsurance) && $userInsurance->insurance ? $userInsurance->insurance->id : old('insurance_id')) == $id ? 'selected' : '' }}>{{ $insurance }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('insurance_id'))
                                <p class="help-block">
                                    {{ $errors->first('insurance_id') }}
                                </p>
                            @endif
                        </div>
                        <div class="form-group {{ $errors->has('amount') ? 'has-error' : '' }}">
                            <label for="amount">{{ trans('cruds.userInsurance.fields.amount') }}*</label>
                            <input type="number" id="amount" name="amount" class="form-control" value="{{ old('amount', isset($userInsurance) ? $userInsurance->amount : '') }}" step="0.01" required>
                            @if($errors->has('amount'))
                                <p class="help-block">
                                    {{ $errors->first('amount') }}
                                </p>
                            @endif
                            <p class="helper-block">
                                {{ trans('cruds.userInsurance.fields.amount_helper') }}
                            </p>
                        </div>
                        <div>
                            <input class="btn btn-danger" type="submit" value="{{ trans('global.save') }}">
                        </div>
                    </form>


                </div>
            </div>

        </div>
    </div>
</div>
@section('scripts')
    <script type="text/javascript">
        $(document).ready(function(){
            $('#assistance').on('change',function(){
                var assistance_id = $(this).val();
                $.ajax({
                    method : 'GET',
                    url : '/admin/get_insurances/'+assistance_id,
                    success : function(data){
                        if (data.success) {
                            $('#insurance option').remove();
                            $("#insurance").append('<option value="">Choose</option>');
                            $.each(data.data, function(){
                                    $("#insurance").append('<option value="'+ this.id +'">'+ this.company_name +'</option>');
                            });
                        }
                    }
                });
            })
        });
    </script>
@endsection
@endsection