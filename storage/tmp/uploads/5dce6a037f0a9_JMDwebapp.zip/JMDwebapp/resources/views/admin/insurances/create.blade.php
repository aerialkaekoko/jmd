@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
            {{ trans('global.create') }} {{ trans('cruds.insurance.title_singular') }}
    </div>

    <div class="card-body">
        <form action="{{ route("admin.insurances.store") }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{ $errors->has('company_name') ? 'has-error' : '' }}">
                <label for="company_name">{{ trans('cruds.insurance.fields.company_name') }}*</label>
                <input type="text" id="company_name" name="company_name" class="form-control" value="{{ old('company_name', isset($insurance) ? $insurance->company_name : '') }}" required>
                @if($errors->has('company_name'))
                    <p class="help-block">
                        {{ $errors->first('company_name') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.insurance.fields.company_name_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('phone') ? 'has-error' : '' }}">
                <label for="phone">{{ trans('cruds.insurance.fields.phone') }}</label>
                <input type="text" id="phone" name="phone" class="form-control" value="{{ old('phone', isset($insurance) ? $insurance->phone : '') }}">
                @if($errors->has('phone'))
                    <p class="help-block">
                        {{ $errors->first('phone') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.insurance.fields.phone_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('address') ? 'has-error' : '' }}">
                <label for="address">{{ trans('cruds.insurance.fields.address') }}</label>
                <input type="text" id="address" name="address" class="form-control" value="{{ old('address', isset($insurance) ? $insurance->address : '') }}">
                @if($errors->has('address'))
                    <p class="help-block">
                        {{ $errors->first('address') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.insurance.fields.address_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('assistance_id') ? 'has-error' : '' }}">
                <label for="assistance">{{ trans('cruds.insurance.fields.assistance') }}*</label>
                <select name="assistance_id" id="assistance" class="form-control select2" required>
                    @foreach($assistances as $id => $assistance)
                        <option value="{{ $id }}" {{ (isset($insurance) && $insurance->assistance ? $insurance->assistance->id : old('assistance_id')) == $id ? 'selected' : '' }}>{{ $assistance }}</option>
                    @endforeach
                </select>
                @if($errors->has('assistance_id'))
                    <p class="help-block">
                        {{ $errors->first('assistance_id') }}
                    </p>
                @endif
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="{{ trans('global.save') }}">
            </div>
        </form>
    </div>
</div>
@endsection