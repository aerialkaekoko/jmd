@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.show') }} {{ trans('cruds.invoices.title') }}
    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.id') }}
                        </th>
                        <td>
                            {{ $invoice->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.invoices.fields.invoice_code') }}
                        </th>
                        <td>
                            {{ $invoice->invoice_code }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.invoices.fields.reference_no') }}
                        </th>
                        <td>
                            {{ $invoice->reference_no }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.invoices.fields.user') }}
                        </th>
                        <td>
                            {{ $invoice->user->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.invoices.fields.hospital') }}
                        </th>
                        <td>
                            {{ $invoice->hospital->name }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.invoices.fields.insurance') }}
                        </th>
                        <td>
                            {{ $invoice->insurance->company_name }}
                        </td>
                    </tr>
                </tbody>
            </table>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr class="bg-primary"><td colspan="2">Expenses</td></tr>
                    <tr>
                        <td>Expense Type</td>
                        <td>Expense Amount</td>
                    </tr>
                    @foreach ($invoice->medical_expenses as $item)
                        <tr>
                            <td>{{$item->expense_type}}</td>
                            <td>{{$item->expense_amount}}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <a style="margin-top:20px;" class="btn btn-default" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>


    </div>
</div>
@endsection