@extends('layouts.admin')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    JMD APPLICATION
                </div>

                <div class="card-body">
                   <!--  @if(session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in! -->
                    <div class="row">
                        <div class="col-lg-6">
                            <h2>Profit & Loss Statement</h2>
                            <canvas id="bar-chart-grouped" width="800" height="450"></canvas>
                        </div>
                        <div class="col-lg-6">
                            <h2>Member Statement</h2>
                            <canvas id="line-chart" width="800" height="450"></canvas>
                        </div>
                    </div>
                    <br/><br/><br/>

                    <div class="row">
                        <div class="col-lg-6">
                            <h2>Chart Three</h2>
                            <canvas id="doughnut-chart" width="800" height="450"></canvas>
                        </div>
                        <div class="col-lg-6">
                            <h2>Profit / Loss Statement</h2>
                            <canvas id="bar-chart-grouped1" width="800" height="450"></canvas>
                        </div>
                       
                    </div>
                    <hr/>

                    <div class="row">
                        <div class="col-lg-6">
                             <h2>Event Calendar</h2><br/>
                            <div id="container"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


</div>
@endsection

@section('scripts')
@parent

@endsection