<?php

return [
    'site_title' => 'jmd',
];
